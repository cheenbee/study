# 让 iOS7 支持 - containsString:
## containsString 只支持 iOS8.0 及以后版本
```
- containsString:
Returns whether the receiver contains a given string by performing a case-sensitive, locale-unaware search.

Declaration
SWIFT
func containsString(_ str: String) -> Bool
OBJECTIVE-C
- (BOOL)containsString:(NSString *)str
Parameters
str	
The string to search for. This value must not be nil.
Return Value
YES if the receiver contains str, otherwise NO.

Discussion
Calling this method is equivalent to calling rangeOfString:options: with no options.

Availability
Available in iOS 8.0 and later.
```

## 新建一个 NSString 分类 Contains
```
#import "NSString+Contains.h"

@implementation NSString (Contains)

- (BOOL)gw_containsString:(NSString *)other {
    NSRange range = [self rangeOfString:other];
    return range.length != 0;
}

@end
```
## 参考链接
[NSString containsString crashes](http://stackoverflow.com/a/26416172/6122246)

