# ZXingObjc 中 EXC_BAD_ACESS in -[ZXCapture dealloc]: 崩溃

###### 使用第三方框架出现错误,如果找不到相应的解决方法,建议到github上对应的框架issues里查找解决方法,若没有可提供具体错误信息提issue给作者

###### 替换修改 ZXCapture dealloc 方法

```
- (void)dealloc {
    /**
  if (_lastScannedImage) {
    CGImageRelease(_lastScannedImage);
  }

  if (_session && _session.inputs) {
    for (AVCaptureInput *input in _session.inputs) {
      [_session removeInput:input];
    }
  }

  if (_session && _session.outputs) {
    for (AVCaptureOutput *output in _session.outputs) {
      [_session removeOutput:output];
    }
  }*/
  
    [self.layer removeFromSuperlayer];
    self.delegate = nil;
    [self stop];
}
```

#####详文: [ZXingObjC/issues/26](https://github.com/TheLevelUp/ZXingObjC/issues/26)
![](http://obr2ozlb6.bkt.clouddn.com/15029425682148.jpg)



