# symbol(s) not found for architecture arm64
更新 Cocoapods 之后,向项目里添加了一个框架,然后更新库,之后出现此错误: **symbol(s) not found for architecture arm64** 


![](http://obr2ozlb6.bkt.clouddn.com/image/blog/14775401706953.jpg)

注意到警告: ![](http://obr2ozlb6.bkt.clouddn.com/image/blog/14775405450988.jpg)

**ld: warning: ignoring file /Users/aiyouyou/Library/Developer/Xcode/DerivedData/**GW-awrjswozfdxdwkbnngmcptbgcvlk/Build/Products/Debug-iphoneos/libAFNetworking.a, file was built for archive which is not the architecture being linked (arm64): /Users/aiyouyou/Library/Developer/Xcode/DerivedData/GW-awrjswozfdxdwkbnngmcptbgcvlk/Build/Products/Debug-iphoneos/libAFNetworking.a



##### 解决
错误提示 Xcode 缓存文件中 libAFNetworking.a 不支持 arm64 架构,  尝试 [StackOverFlow](http://stackoverflow.com/questions/19213782/undefined-symbols-for-architecture-arm64/35786482#35786482) 上的解决方法,只有删除清空  **Xcode 缓存文件(~/Library/Developer/Xcode/DerivedData/)**可以解决,由此推测这个问题是因为 Cocopods 没有支持 arm64 架构,所以不能使用和更新 Cocopods 下载的包,想起来之前刚更新完 Cocopods, 所以可能是更新 Cocoapods 与之前的版本下载的第三方包不兼容所致,,删除缓存文件即可解决
![](http://obr2ozlb6.bkt.clouddn.com/image/blog/14778843618736.jpg)


##### 参考链接在此
[Undefined symbols for architecture arm64](http://stackoverflow.com/questions/19213782/undefined-symbols-for-architecture-arm64/35786482#35786482)

With Partener [张旭](http://www.jianshu.com/users/153fa208d4a8/latest_articles)


