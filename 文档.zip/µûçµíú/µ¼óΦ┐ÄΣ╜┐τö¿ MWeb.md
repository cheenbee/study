# 欢迎使用 MWeb

首先介绍一下 MWeb 是什么，MWeb 是专业的 Markdown 写作、记笔记、静态博客生成软件。MWeb 使用的是 Github Flavored Markdown 语法，在使用 MWeb 前，建议你一定要去 [MWeb 官网首页](http://zh.mweb.im/) 看一下介绍视频，MWeb 官网也做了比较详细的帮助，建议你也看一下大概内容，帮助的网址为：<http://zh.mweb.im/help.html>。

## 需要您重点注意的

MWeb 是有**两种模式**的：外部模式和文档库模式。MWeb 为了满足所有 Markdown 使用需求，设计了两种模式！外部模式用于打开和编辑所有本地 Markdown 文档。另外为了方便用 Markdown 记笔记，MWeb 设计了文档库模式，文档库中的文档也支持一键生成静态博客，以便于分享。关于两个模式的情况，还是建议您去看一下官网的视频和帮助。

## 帮助我们改进 MWeb

如果你喜欢 MWeb，想让它变得更好，你可以：

1. 推荐 MWeb，让更多的人知道。
2. 给我们发反馈和建议：<coderforart+233@gmail.com>
3. 在 Mac App Store 上评价 （如果是在 MAS 上购买的话）。

