# WKWebView 替换 UIWebView
1. 准备加载页面

```
 UIWebViewDelegate: - webView:shouldStartLoadWithRequest:navigationType
 WKNavigationDelegate: - webView:didStartProvisionalNavigation:
```

