## Code Sign 证书相关
[Code Sign Identity](http://stackoverflow.com/a/16070915/6122246)

## [浅谈 iOS 版本号](https://segmentfault.com/a/1190000002423661)

## [Objective-C Runtime](http://justsee.iteye.com/blog/2163777)

##  po NSHomeDirectory() LLDB 中查看 模拟器沙盒目录
## [图片压缩](https://viktyz.gitbooks.io/iosnotebook/content/Notes/Note_00136_20160122.html)

##[超多资源链接收藏](http://www.jianshu.com/p/ee15c1cf9c16)
## [iOS小技巧总结](http://www.jianshu.com/p/4523eafb4cd4)


