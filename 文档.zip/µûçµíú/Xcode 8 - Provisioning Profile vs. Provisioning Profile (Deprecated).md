# Xcode 8 - Provisioning Profile vs. Provisioning Profile (Deprecated)

[](http://stackoverflow.com/questions/39488782/xcode-8-provisioning-profile-vs-provisioning-profile-deprecated)

