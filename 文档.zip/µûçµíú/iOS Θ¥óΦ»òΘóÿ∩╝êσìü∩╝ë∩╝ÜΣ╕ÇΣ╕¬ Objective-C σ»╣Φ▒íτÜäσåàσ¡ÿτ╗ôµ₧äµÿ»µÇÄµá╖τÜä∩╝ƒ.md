# iOS 面试题（十）：一个 Objective-C 对象的内存结构是怎样的？
原创 2017-01-17 唐巧 iOS开发by唐巧
### 问题

一个 Objective-C 对象的内存结构是怎样的？

### 答案

这是一道老题，或许很多人都准备过，其实如果不是被每个公司都考查的话，这道题可以看看候选人对于 iOS 背后底层原理的感兴趣程度。真正对编程感兴趣的同学，都会对这个多少有一些好奇，进而在网上搜索并学习这方面的资料。

以下是本题的简单回答：

如果把类的实例看成一个C语言的结构体（struct），它首先包含的是一个 isa 指针，而类的其它成员变量依次排列在结构体中。排列顺序如下图所示：
![](media/14877301085008/14877301808987.jpg)


为了验证该说法，我们在Xcode中新建一个工程，在main.m中运行如下代码：

```
#import <UIKit/UIKit.h>

@interface Father : NSObject {    
    int _father;
}
@end@implementation Father

@end

@interface Child : Father {    
int _child;
}
@end

@implementation Child

@end

int main(int argc, char * argv[])
{

  Child * child = [[Child alloc] init];  
  @autoreleasepool {      
       // ...
  }
}
```
我们将断点下在 @autoreleasepool 处，然后在Console中输入p *child,则可以看到Xcode输出如下内容，这与我们上面的说法一致。
```
(lldb) p *child
(Child) $0 = {
  (Father) Father = {
    (NSObject) NSObject = {
      (Class) isa = Child
    }
    (int) _father = 0
  }
  (int) _child = 0
}
```
因为对象在内存中的排布可以看成一个结构体，该结构体的大小并不能动态变化。所以无法在运行时动态给对象增加成员变量。

注：需要特别说明一下，通过 objc_setAssociatedObject 和 objc_getAssociatedObject方法可以变相地给对象增加成员变量，但由于实现机制不一样，所以并不是真正改变了对象的内存结构。


