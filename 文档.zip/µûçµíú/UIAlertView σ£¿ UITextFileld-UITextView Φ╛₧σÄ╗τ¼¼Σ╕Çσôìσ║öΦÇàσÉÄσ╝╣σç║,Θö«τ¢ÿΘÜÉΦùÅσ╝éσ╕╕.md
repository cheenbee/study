# UIAlertView 在 UITextFileld/UITextView 辞去第一响应者后弹出,键盘隐藏异常
UITextField 辞去第一响应者,键盘隐藏,若紧接着弹出 UIAlertView ,此时 alertView 消失后键盘会再次快速的弹起并隐藏.

```
UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil message:message delegate:nil cancelButtonTitle:nil otherButtonTitles:nil, nil];
[alertView show];
```      

因 alertView 弹出动画与 键盘隐藏动画 起冲突所致 

### 解决:

让 alertView 延迟 (0.5秒) 弹出,可避免冲突  

```
UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil message:message delegate:nil cancelButtonTitle:nil otherButtonTitles:nil, nil];

dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [alertView show];
    });
```          
                                                


### 参考链接
[IOS-65-解决UIAlertView导致界面弹出键盘的问题](http://blog.csdn.net/iot_li/article/details/51838820)
[Can't hide keyboard in UIViewController stack when UIAlertView is on screen](http://stackoverflow.com/questions/7936181/cant-hide-keyboard-in-uiviewcontroller-stack-when-uialertview-is-on-screen?rq=1)
[Keyboard loses hiding ability “if I use a UIAlertView”](http://stackoverflow.com/questions/6692319/keyboard-loses-hiding-ability-if-i-use-a-uialertview?rq=1)

With Partener [张旭](http://www.jianshu.com/users/153fa208d4a8/latest_articles)


