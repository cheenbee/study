# iOS 逆向
#### 工具
* class-dump [Objective-C Class-dump 安装和使用](https://cnbin.github.io/blog/2015/05/21/objective-c-class-dump-an-zhuang-he-shi-yong-fang-fa/)
* Interface Inspector
* Hopper Disassembler 
* EasySIMBL [使用EasySIMBL为Mac应用加载插件](http://www.poboke.com/study/use-easysimbl-to-inject-plugins-to-mac-app.html)

##### 给予目录权限
sudo chmod 777 directory

