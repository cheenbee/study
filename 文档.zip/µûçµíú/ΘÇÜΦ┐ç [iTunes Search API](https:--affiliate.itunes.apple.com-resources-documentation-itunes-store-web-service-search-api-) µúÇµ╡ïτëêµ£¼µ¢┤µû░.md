# 通过 [iTunes Search API](https://affiliate.itunes.apple.com/resources/documentation/itunes-store-web-service-search-api/) 检测版本更新
![-w375](http://obr2ozlb6.bkt.clouddn.com/2016-12-13-14816190551301.jpg)
#### 苹果对版本更新的限定
1. 若你的 app 中有 用户可以主动检测更新的入口, 苹果审核时会被拒, 偶然间发现 手机QQ 的一个作弊手段, 当你手机上的 QQ 有更新版本时,在 app 设置中会出现提示你去更新的入口,若你的 QQ 已经是最新版本时,此入口会隐藏
2. 有更新版本时,正确不会被拒的更新方法,是提示用户选择更新,而不是让用户主动检测更新    

#### 获取 App Store 上最新版本方法
###### 使用 GET 或 POST 方式发送请求:
1. 根据 app 名称查询 https://itunes.apple.com/search?term=AppName, AppName 若是中文需要转码成 UTF-8 格式, `[appName stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]`
2. 根据 app ID 查询 https://itunes.apple.com/lookup?id=AppID ,此方法查找精度高,速度快,推荐使用    
    
* PS: 接口中拼接的参数越具体,查询的速度越快,具体参数请参照 [iTunes Search API](https://affiliate.itunes.apple.com/resources/documentation/itunes-store-web-service-search-api/), 如第一种查询方式,若只查询 iTunes Store 中的**应用**,可在接口地址后面拼接 https://itunes.apple.com/search?term=AppName&entity=software 
 
###### 查询接口返回的结果是 JSON 格式数据
接口返回数据的具体说明请参照 [Understanding Search Results](https://affiliate.itunes.apple.com/resources/documentation/itunes-store-web-service-search-api/#understand), 以下给出一些主要参数说明:   

```
{
	"resultCount": 1,
	"results": [
		{
			"artistId": 开发者ID,
			"artistName": "开发者名称",
			"artistViewUrl": "iTunes上开发者介绍页面",
			"description": "描述-内容提要",
			"fileSizeBytes": "安装包大小(KB)",
			"kind": "software",
			"releaseNotes": "版本信息-最新动态",
			"trackContentRating": "应用内容评级",
			"trackId": 应用ID,
			"trackName": "应用名称",
			"trackViewUrl": "应用在 iTunes 介绍网址即下载更新地址",
			"version": "应用最新版本号",
			"wrapperType": "software"
		}
	]
}
```
 
 
 本文使用 AFN 进行网络请求 查询应用信息  
 
 ```
 NSString *urlString = [NSString stringWithFormat:@"https://itunes.apple.com/lookup?id=%@", appID];
 AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
 NSURLSessionDataTask *task = [manager POST:urlString parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if (responseObject) {
            NSDictionary *resultsDict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
            NSArray *resultsArray = [resultsDict arrayObjectForKey:@"results"];
            NSDictionary *releaseInfo = [resultsArray objectAtIndex:0];
            // 最新版本号
            NSString *latestVersion = [releaseInfo objectForKey:@"version"]; 
            // 更新下载地址
            NSString *trackViewUrl = [releaseInfo objectForKey:@"trackViewUrl"];
            // 版本更新描述
            NSString *releaseNotes = [releaseInfo objectForKey:@"releaseNotes"];
        }        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
    }];
 ```
#### 与本地 app 版本号对比 

一般在应用启动后, 即 **AppDelegate** 的 `- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions` 方法中进行检测更新提示:    

```
NSDictionary *infoDic = [[NSBundle mainBundle] infoDictionary];
NSString *currentAppVersion = [infoDic objectForKey:@"CFBundleShortVersionString"];
// 此处的 latestVersion 为上文中查询到的 版本号
if ([currentAppVersion compare:latestVersion] == NSOrderedAscending) {
    // 有更新版本,提示更新
}
``` 

#### 更新提示
可自定义提示框显示出: 更新版本号(latestVersion), 更新版本信息(releaseNotes)
点击去更新按钮,使用代码跳转到 App Store 应用下载页

```
UIApplication *application = [UIApplication sharedApplication];
if ([application canOpenURL:[NSURL URLWithString:trackViewUrl]]) {
    [application openURL:[NSURL URLWithString:trackViewUrl]];
}                      
```
#### 视需求而定提示更新的时机
1. 每次应用启动后进行一次检测更新
2. 检测有更新版本,而此时却在显示引导页,为防止与引导页冲突,待引导页消失后,再进行更新提示
3. 用户选择了取消更新,再次重新进入应用不再进行更新检测   

#### 参阅
1. [iTunes Search API](https://affiliate.itunes.apple.com/resources/documentation/itunes-store-web-service-search-api/)
2. [通过iTunes search检测版本更新!](http://www.iliunian.com/1994.html)



