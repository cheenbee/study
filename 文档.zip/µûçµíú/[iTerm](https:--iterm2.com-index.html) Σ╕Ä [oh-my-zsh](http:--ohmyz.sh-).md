# [iTerm](https://iterm2.com/index.html) 与 [oh-my-zsh](http://ohmyz.sh/)
[Zsh 配置介绍(简体中文)](https://wiki.archlinux.org/index.php/Zsh_(%E7%AE%80%E4%BD%93%E4%B8%AD%E6%96%87)#.E5.B0.86_Zsh_.E4.BD.9C.E4.B8.BA.E9.BB.98.E8.AE.A4.E7.BB.88.E7.AB.AF)

