## 自定义iOS系统字体
iOS8 系统默认的中文字体是 Heiti (常州华文黑体), iOS9 默认的中文字体是 PingFang (苹方), iOS10 默认中文字体也是苹方,但 iOS10的字体要比iOS9的字体

1. 将字体资源拖进Xcode工程
2. 打印Xcoed中包含的字体
for(NSString *fontFamilyName in [UIFont familyNames])
    {
        NSLog(@"family:'%@'",fontFamilyName);
        for(NSString *fontName in [UIFont fontNamesForFamilyName:fontFamilyName])
        {
            NSLog(@"\tfont:'%@'",fontName);
        }
        NSLog(@"-------------");
    }
### iOS10 中系统字体变大,导致之前固定宽度的控件字体显示不全
#### 代码更改字体
#### xib中修改字体

