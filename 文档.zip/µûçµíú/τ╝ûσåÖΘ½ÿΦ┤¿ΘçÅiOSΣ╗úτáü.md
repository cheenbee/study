# 编写高质量iOS代码

###### 1.多用类型常量,少用#define预处理指令
 `static const NSString *kName = @"Snow";`
 命名方法: 若常量局限于实现文件之内,则在前面加字母k;若常量在类之外可见,则通常以类名为前缀.
 
 2.
 
 

